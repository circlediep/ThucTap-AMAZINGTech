﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace XuongMay.Data
{
    [Table("Account")]
    public class User
    {
        
        public int Id { get; set; }
        [MaxLength(20)]
        public string Name { get; set; }
        public string Password { get; set; }
    }
}
