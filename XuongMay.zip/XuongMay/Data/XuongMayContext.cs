﻿using Microsoft.EntityFrameworkCore;

namespace XuongMay.Data
{
    public class XuongMayContext:DbContext
    {
        public XuongMayContext(DbContextOptions<XuongMayContext> opt): base(opt) { }
        #region DbSet
        public DbSet<User> Users { get; set; }
        #endregion
    }
}
